const aws = require('aws-sdk');
const rekognition = new aws.Rekognition({apiVersion: '2016-06-27'});

exports.handler = async (event, context) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // ファイル情報の取得
    const bucket = event.Records[0].s3.bucket.name;
    const key = decodeURIComponent(event.Records[0].s3.object.key);

    // startLabelDetectionのパラメータ設定
    var rekoParams = {
      Video: {
        S3Object: {
          Bucket: bucket,
          Name: key
        }
      },
      MinConfidence: 90.0,
      NotificationChannel: {
        RoleArn: process.env['ROLE_ARN'],
        SNSTopicArn: process.env['SNS_TOPIC_ARN']
      }
    };

    // Rekognitionへ解析要求
    try {
      const data = await rekognition.startLabelDetection(rekoParams).promise();
      console.log(data);
      return data;
    } catch(err) {
      console.log(err, err.stack);
      return err;
    }
};