const aws = require('aws-sdk');
const s3 = new aws.S3({apiVersion: '2006-03-01'});
const rekognition = new aws.Rekognition({apiVersion: '2016-06-27'});

exports.handler = async (event, context) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    const message = JSON.parse(event.Records[0].Sns.Message);
    console.log('From SNS:', message);

    // 分析ステータスの確認
    if( message.Status != 'SUCCEEDED') {
      // 成功していなければ終了
      console.log('Status is not SUCCEEDED');
      return;   
    }

    // ラベル分析結果の取得
    var rekoParams = {
      JobId: message.JobId
    };
    try {
      do {
        const rekoRes = await rekognition.getLabelDetection(rekoParams).promise();
  
        // 人物が映っているかの確認
        if(rekoRes.JobStatus === 'SUCCEEDED')
        {
          // ラベルの検索
          var labels = rekoRes.Labels;
          for(var idx in labels) {
            console.log("name:", labels[idx].Label.Name);
            // 要求時のMinConfidenceを満たして入れば映っていると判断する
            if(labels[idx].Label.Name === 'Human') {
              // 見つかった場合はファイルはそのまま
              console.log('Human has detected');
              return;
            }
          }
        }

        console.log('NextToken:', rekoRes.NextToken);
        // NextTokenがある場合はラベルの取得を継続
        rekoParams.NextToken = rekoRes.NextToken;
      } while (rekoParams.NextToken != undefined)
    } catch(err) {
      console.log(err, err.stack);
      return err;
    }
    
    // ファイルの削除
    var s3Params = {
      Bucket: message.Video.S3Bucket, 
      Key: message.Video.S3ObjectName
    };
    console.log('delete file:', s3Params.Key);
    try {
      const s3Res = await s3.deleteObject(s3Params).promise();
      console.log('delete complete:', s3Res);
    } catch(err) {
      console.log(err, err.stack);
      return err;
    }
};